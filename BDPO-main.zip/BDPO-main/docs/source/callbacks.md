# Callbacks

## SyncRefModelCallback

[[autodoc]] SyncRefModelCallback

## RichProgressCallback

[[autodoc]] RichProgressCallback

## WinRateCallback

[[autodoc]] WinRateCallback

## LogCompletionsCallback

[[autodoc]] LogCompletionsCallback

## MergeModelCallback

[[autodoc]] MergeModelCallback