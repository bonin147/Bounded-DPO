# Data Utilities

## is_conversational

[[autodoc]] is_conversational

## apply_chat_template

[[autodoc]] apply_chat_template

## maybe_apply_chat_template

[[autodoc]] maybe_apply_chat_template

## extract_prompt

[[autodoc]] extract_prompt

## maybe_extract_prompt

[[autodoc]] maybe_extract_prompt

## unpair_preference_dataset

[[autodoc]] unpair_preference_dataset

## maybe_unpair_preference_dataset

[[autodoc]] maybe_unpair_preference_dataset
